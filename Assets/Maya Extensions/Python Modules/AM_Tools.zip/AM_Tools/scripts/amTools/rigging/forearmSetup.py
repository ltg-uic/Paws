"""
A GUI to automatically create the twist structure for a forearm.

To use this tool, select one or more wrist joints and enter the desired data
into the option fields before pressing either the Create or Apply button.

To skin to the model, the forearm mesh should be skinned in segments for each
twist joint, plus one additional for the elbow joint, where the segment at the
proximal end of the elbow is skinned to the elbow joint and the final segment
before the hand is skinned to the final twist joint.

\par Setup Forearm Options:
- \b Suffix \b of \b New \b Twist \b Joints:
Specifies the base naming suffix to apply to the newly created joints. Their
prefix will match the shoulder on which they are twisting and they will also be
numbered from 1 to n.
- \b Number \b of \b Twist \b Joints:
Specifies the number of twist joints to create for each hip. You must create at
least one and the first will always have the hip constraint applied to it.
\par Aim Constraint Options:
- \b Elbow \b Aim \b Axis:
Corresponds to the axis in the forearm's local space that aims toward the hand
joint.
- \b Elbow \b Front \b Axis:
Corresponds to the axis in the forearm's local space that points toward the
character's front.
- \b Hand \b Front \b Axis:
Corresponds to the axis in the hand's local space that points toward the front
side of the hand (the side with the thumb on it).

\b Creation \b Info:

\b Donations: http://adammechtley.com/donations/

\b License: The MIT License

Copyright (c) 2011 Adam Mechtley (http://adammechtley.com)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the 'Software'), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED 'AS IS', WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

\namespace amTools.rigging.forearmSetup
"""

import sys
import maya.cmds as cmds
import amTools.utilities as utils
import amTools.utilities.ui as amui

## options window name
kSetupOptionsWindow = 'am_setupForearmOptionsWindow'
## name of the tool
kToolName = 'Setup Forearm'
## current version of the tool
kVersionNumber = '1.03'
## date of current version
kVersionDate = '2011.03.27'

def menuItem(*args):
	"""This function calls optionsWindow() from a menu item"""
	optionsWindow()

def optionsWindow():
	"""This function creates an options window for creating the forearm twist
	structure. When executing it, select the wrists in the arms you are setting
	up, then press Create or Apply."""
	# create the main interface
	if cmds.window(kSetupOptionsWindow, q=True, ex=True):
		cmds.deleteUI(kSetupOptionsWindow)
	mainWindow = cmds.window(kSetupOptionsWindow, title='%s Options'%kToolName, menuBar=True, wh=(545,350))
	
	# build the menu bar
	cmds.menu(label='Help')
	amui.helpMenuItem(kToolName, __file__)
	amui.aboutMenuItem(kToolName, kVersionNumber, kVersionDate)
	
	mainForm = cmds.formLayout(nd=100)
	
	# build the section to get information about the new twist joints
	if_suffixName = cmds.textFieldGrp(text='_Twist', label='Suffix of New Twist Joints:')
	if_numberTwistJoints = cmds.intSliderGrp(v=3, min=1, max=10, fmn=1, fmx=100, label='Number of Twist Joints:', field=True)
	
	# position the input fields for the twist joints
	cmds.formLayout(mainForm, edit=True, attachForm=[(if_suffixName, 'left', 30), (if_suffixName, 'top', 5)], attachNone=[(if_suffixName, 'right'), (if_suffixName, 'bottom')])
	cmds.formLayout(mainForm, edit=True, attachForm=[(if_numberTwistJoints, 'left', 30)], attachNone=[(if_numberTwistJoints, 'right'), (if_numberTwistJoints, 'bottom')], attachControl=[(if_numberTwistJoints, 'top', 5, if_suffixName)])
	
	# build the section to get information for the aim constraint
	constraintFrame = eval('cmds.frameLayout(collapsable=True, label="Aim Constraint Options:" %s)'%amui.__frameAlignCenter__)
	constraintForm = cmds.formLayout(nd=100)
	
	if_elbowAimAxis = cmds.floatFieldGrp(v1=1, v2=0, v3=0, nf=3, pre=4, label='Elbow Aim Axis:')
	if_elbowFrontAxis = cmds.floatFieldGrp(v1=0, v2=0, v3=1, nf=3, pre=4, label='Elbow Front Axis:')
	if_handFrontAxis = cmds.floatFieldGrp(v1=0, v2=0, v3=1, nf=3, pre=4, label='Hand Front Axis:')
	
	# position the input fields for the aim constraint
	cmds.formLayout(constraintForm, edit=True, attachForm=[(if_elbowAimAxis, 'left', 30), (if_elbowAimAxis, 'top', 5)], attachNone=[(if_elbowAimAxis, 'right'), (if_elbowAimAxis, 'bottom')])
	cmds.formLayout(constraintForm, edit=True, attachForm=[(if_elbowFrontAxis, 'left', 30)], attachNone=[(if_elbowFrontAxis, 'right'), (if_elbowFrontAxis, 'bottom')], attachControl=[(if_elbowFrontAxis, 'top', 5, if_elbowAimAxis)])
	cmds.formLayout(constraintForm, edit=True, attachForm=[(if_handFrontAxis, 'left', 30)], attachNone=[(if_handFrontAxis, 'right'), (if_handFrontAxis, 'bottom')], attachControl=[(if_handFrontAxis, 'top', 5, if_elbowFrontAxis)])
	
	cmds.setParent('..') # go up to constraintForm
	cmds.setParent('..') # go up to mainForm
	
	# position the frame for the aim constraint
	cmds.formLayout(mainForm, edit=True, attachPosition=[(constraintFrame, 'left', -1, 0), (constraintFrame, 'right', -1, 100)], attachControl=[(constraintFrame, 'top', 5, if_numberTwistJoints)], attachNone=[(constraintFrame, 'bottom')])
	
	# create the buttons to execute the script
	cmd_create='amTools.rigging.forearmSetup.doOptions ("%s", "%s", "%s", "%s", "%s")'%(
		if_suffixName, 
		if_numberTwistJoints, 
		if_elbowAimAxis, 
		if_elbowFrontAxis, 
		if_handFrontAxis)
	utils.ui.threeButtonLayout(mainForm, mainWindow, cmd_create)
	
	cmds.showWindow(mainWindow)

def doOptions(input_suffix, input_numberTwistJoints, input_elbowAimAxis, input_elbowFrontAxis, input_handFrontAxis):
	"""Specifies the function called when the apply or create button is clicked"""
	try:
		# validate selection
		selection = utils.dg.validateSelection(type='transform', name='wrist joint objects', min=1)
		
		# validate suffix
		suffix = cmds.textFieldGrp(input_suffix, q=True, tx=True)
		utils.dg.validateAffix(suffix)
		
		# set up the forearms
		numberTwistJoints = cmds.intSliderGrp(input_numberTwistJoints, q=True, v=True)
		newSelection = []
		# perform setup for each wrist in the selection
		for wrist in selection:
			elbow = cmds.listRelatives(wrist, p=True, f=True)
			elbowShort = cmds.listRelatives(wrist, p=True)
			newJoints = doSetup(
				elbowShort[0] + suffix, 
				numberTwistJoints, 
				wrist, 
				elbow[0], 
				cmds.floatFieldGrp(input_elbowAimAxis, q=True, v=True), 
				cmds.floatFieldGrp(input_elbowFrontAxis, q=True, v=True), 
				cmds.floatFieldGrp(input_handFrontAxis, q=True, v=True))
			newSelection += newJoints
		# select the newly created joints for easy editing
		cmds.select(newSelection)
	except: raise

def doSetup(baseName, numberTwistJoints, wrist, elbow, elbowAimAxis, elbowFrontAxis, handFrontAxis):
	"""This function creates the new twist joints and returns a list of their names."""
	try:
		# validate baseName
		utils.dg.validateNodeName(baseName)
		
		# validate incoming object names
		utils.dg.verifyNode(wrist)
		utils.dg.verifyNode(elbow)
		
		# get the translation values for the wrist
		wristTranslate = cmds.getAttr('%s.translate'%wrist)
		
		# see if there is a side label
		bodySide = cmds.getAttr('%s.side'%elbow)
		
		# find out what rotate order the elbow is using
		rotateOrder = cmds.getAttr('%s.rotateOrder'%elbow)
		
		# create the twist joints
		twistJoints = []
		
		for ctr in range(numberTwistJoints):
			i = numberTwistJoints - ctr
			cmds.select(cl=True)
			newJoint = cmds.joint(name='%s%s'%(baseName, i))
			jointRadius = 0.0
			cmds.parent('|' + newJoint, elbow)
			newJoint = (elbow + '|' + newJoint)
	
			# if the elbow object is a joint, then use its radius and jointOrient as base values
			if cmds.objectType(elbow, isType='joint'): jointRadius = cmds.getAttr('%s.radius'%elbow) * 0.5
			else: jointRadius = 1.0
	
			cmds.setAttr('%s.radius'%newJoint, jointRadius)
			cmds.setAttr('%s.jointOrient'%newJoint, 0, 0, 0)
			cmds.setAttr('%s.translate'%newJoint, wristTranslate[0][0]/(numberTwistJoints+1)*i, wristTranslate[0][1]/(numberTwistJoints+1)*i, wristTranslate[0][2]/(numberTwistJoints+1)*i)
	
			# set up the final joint
			if i is numberTwistJoints:
				# create the aim constraint
				cmds.aimConstraint(
					[wrist, newJoint], 
					aimVector=[elbowAimAxis[0], elbowAimAxis[1], elbowAimAxis[2]], 
					upVector=[elbowFrontAxis[0], elbowFrontAxis[1], elbowFrontAxis[2]], 
					worldUpVector=[handFrontAxis[0], handFrontAxis[1], handFrontAxis[2]], 
					worldUpObject=wrist, 
					worldUpType='objectrotation')
			# set up the rest of the joints
			else:
				# create the orient constraint
				orientConstraint = cmds.orientConstraint(elbow, twistJoints[0], newJoint)
				targetWeights = cmds.orientConstraint(q=True, weightAliasList=True)
				cmds.setAttr('%s.%s'%(orientConstraint[0], targetWeights[0]), numberTwistJoints - i)
				cmds.setAttr('%s.%s'%(orientConstraint[0], targetWeights[1]), i)
				cmds.setAttr('%s.interpType'%orientConstraint[0], 1)
	
			# set label and rotate order
			cmds.setAttr('%s.side'%newJoint, bodySide)
			cmds.setAttr('%s.type'%newJoint, 18)
			cmds.setAttr('%s.otherType'%newJoint, 'Forearm Twist %s'%(i + 1), type='string')
			cmds.setAttr('%s.rotateOrder'%newJoint, rotateOrder)
	
			# add the new joint to the list to return
			twistJoints.append(newJoint)
			
		return twistJoints;
	except: raise