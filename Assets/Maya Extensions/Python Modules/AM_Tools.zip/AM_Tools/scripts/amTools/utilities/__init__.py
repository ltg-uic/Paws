"""
Utility functions for re-use throughout the amTools package.

\b Creation \b Info:

\b Donations: http://adammechtley.com/donations/

\b License: The MIT License

Copyright (c) 2011 Adam Mechtley (http://adammechtley.com)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the 'Software'), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED 'AS IS', WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

\namespace amTools.utilities
"""

import maya.cmds as cmds
import maya.mel as mel
import maya.OpenMaya as OM

import animation
import debug
import dg
import files
import plugins
import ui

## a dictionary of possible rotation order values
kRotateOrderMapping = {
	"xyz" : OM.MEulerRotation.kXYZ, 
	"yzx" : OM.MEulerRotation.kYZX, 
	"zxy" : OM.MEulerRotation.kZXY, 
	"xzy" : OM.MEulerRotation.kXZY, 
	"yxz" : OM.MEulerRotation.kYXZ, 
	"zyx" : OM.MEulerRotation.kZYX,
	"0" : OM.MEulerRotation.kXYZ, 
	"1" : OM.MEulerRotation.kYZX, 
	"2" : OM.MEulerRotation.kZXY, 
	"3" : OM.MEulerRotation.kXZY, 
	"4" : OM.MEulerRotation.kYXZ, 
	"5" : OM.MEulerRotation.kZYX
}

def connectToEclipse():
	"""Open a command port for Eclipse"""
	if not cmds.commandPort(':7720', q=True): cmds.commandPort(n=':7720', nr=True)

def reloadAll():
	"""Reload all modules in this package."""
	# force debug mode to check back in
	apiDebugMode = mel.eval('%s=%s'%(debug.kGlobalAPIDebug, debug.kGlobalAPIDebug))
	if apiDebugMode:
		debug.debugAll(False)
	reload(debug)
	debug.debugAll(apiDebugMode)
	
	reload(animation)
	reload(dg)
	reload(files)
	reload(plugins)
	reload(ui)