"""
Utility functions for working with files. Many functions are primarily intended
to be executed from batch mode.

\par WARNING:
This module has not been extensively tested. I cobbled a lot of these functions
together for a project I needed, and it got the job done, but I make no claims
that any of the batching functions are bulletproof by any stretch (or even
well-designed). I haven't reused a lot of these functions since then, so please
do send me any feedback regarding your experiences!

\b Creation \b Info:

\b Donations: http://adammechtley.com/donations/

\b License: The MIT License

Copyright (c) 2011 Adam Mechtley (http://adammechtley.com)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the 'Software'), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED 'AS IS', WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

\namespace amTools.utilities.files
"""

import maya.cmds as cmds
import maya.mel as mel
import os, sys, inspect, types, math
import amTools

def convertValidTypesToStringList(oldList=[], validTypes=[types.StringTypes]):
	"""Convert an incoming object (oldList) into a list of strings made of only those objects permitted by the validTypes filter."""
	if not type(oldList) == types.ListType or not type(oldList) == types.TupleType:
		for valid in validTypes:
			if isinstance(oldList, valid): oldList = [oldList]
			# used for types that are tuples, such as types.StringTypes
			elif not isinstance(valid, types.TypeType):
				try:
					for otherValid in valid:
						if isinstance(oldList, otherValid): oldList = [oldList]
				except: pass
	if not isinstance(oldList, types.ListType): return []
	newList = []
	for item in oldList:
		for valid in validTypes:
			if isinstance(item, valid): newList.append('%s'%item)
			elif not isinstance(item, valid):
				try:
					for otherValid in valid:
						if isinstance(item, otherValid): newList.append('%s'%item)
				except: pass
	return newList

def find(sourcePath, recursively=True, includeHidden=False, **keywords):
	"""
	Find files in sourcePath that match certain patterns supplied via keywords.
	Hidden file detection is not implemented for Windows. Sorry, but I just
	don't care.
	@param folders Boolean specifying that the caller wants a list of folders rather than files
	@param paths String specifying how paths should be returned with respect to sourcePath: full, relative, or no
	@param filePatterns List corresponding to different file extensions to parse
	@param filterPrefix List corresponding to required prefixes in file names
	@param filterSuffix List corresponding to required suffixes in file names
	@param filterContains List corresponding to required string in file names
	"""
	# parse keywords
	getFolders = False
	try: getFolders = keywords['folders']
	except: pass
	pathMap = {'full' : 0, 'relative' : 1, 'no' : 2}
	paths = 'full'
	try:
		paths = keywords['paths']
		if not paths == 'no' and not paths == 'relative' and not paths == 'full':
			sys.stderr.write('WARNING: Invalid paths argument %s in call to %s.%s(). Using full paths instead.\n'%(paths, __file__, inspect.getframeinfo(inspect.currentframe())[2]))
	except: pass
	try: filePatterns = convertValidTypesToStringList(keywords['filePatterns'], [types.StringTypes, types.IntType])
	except: filePatterns = ['']
	try: filterPrefix = convertValidTypesToStringList(keywords['filterPrefix'], [types.StringTypes, types.IntType, types.FloatType])
	except: filterPrefix = ['']
	try: filterSuffix = convertValidTypesToStringList(keywords['filterSuffix'], [types.StringTypes, types.IntType, types.FloatType])
	except: filterSuffix = ['']
	try: filterContains = convertValidTypesToStringList(keywords['filterContains'], [types.StringTypes, types.IntType, types.FloatType])
	except: filterContains = ['']
	
	# add a trailing slash to the incoming path if absent
	if not sourcePath.rfind('/') == len(sourcePath)-1: sourcePath += '/'
	
	# first search the source path for files that match the input pattern
	found = []
	files = []
	try: found = os.listdir(sourcePath)
	except:
		sys.stderr.write('ERROR: Unable to locate %s.\n'%sourcePath)
		return False
	for item in found:
		# Ignore hidden items -- currently does not support Windows mechanism
		if not includeHidden and (not os.name == 'nt' and item[item.rfind('/')+1:len(item)].find('.') == 0): continue
		# If the file is a directory
		if os.path.isdir('%s%s'%(sourcePath, item)):
			if getFolders:
				for prefix in filterPrefix:
					if not item[item.rfind('/')+1:len(item)].startswith(prefix): continue
					for suffix in filterSuffix:
						if not item[0:item.rfind('.')].endswith(suffix): continue
						for substring in filterContains:
							if item.find(substring) > -1:
								if pathMap[paths] == 0: files.append('%s%s'%(sourcePath, item))
								elif pathMap[paths] == 1: files.append(item)
								else: files.append(item[item.rfind('/')+1:len(item)])
			if recursively:
				try:
					subfileList = os.listdir('%s%s'%(sourcePath, item))
					for subfile in subfileList:
						found.append('%s/%s'%(item, subfile))
				except:
					sys.stderr.write('WARNING: Could not access file: %s\n'%item)
					pass
		# If the file is a file with an extension
		elif os.path.isfile('%s%s'%(sourcePath, item)) and not getFolders:
			for pattern in filePatterns:
				if not item.endswith(pattern): continue
				for prefix in filterPrefix:
					if not item[item.rfind('/')+1:len(item)].startswith(prefix): continue
					for suffix in filterSuffix:
						if not item[0:item.rfind('.')].endswith(suffix): continue
						for substring in filterContains:
							if item.find(substring) > -1:
								if pathMap[paths] == 0: files.append('%s%s'%(sourcePath, item))
								elif pathMap[paths] == 1: files.append(item)
								else: files.append(item[item.rfind('/')+1:len(item)])
	
	return files

def copyDirectoryStructure(sourcePath, destPath, includeHidden=False):
	"""Copy a directory structure from one location into another location. Returns True on success."""
	# try to create the root directory if it does not exist
	try: os.listdir(sourcePath)
	except:
		try: os.makedirs(destPath)
		except: return False
	# copy subdirectory structure
	directoryStructure = find(sourcePath, True, includeHidden, paths='relative', folders=True)
	for directory in directoryStructure:
		try: os.makedirs('%s/%s'%(destPath, directory))
		except: pass
	return True

## UI configuration flags invalid before Maya 2011
kUIConfigFlags2011 = [
	'-ignorePanZoom',
	'-showUpstreamCurves',
	'-showPinIcons',
	'-showStackedCurves',
	'-stackedCurves',
	'-stackedCurvesMin',
	'-stackedCurvesMax',
	'-stackedCurvesSpace',
	'-displayNormalized',
	'-preSelectionHighlight',
	'-manageSequencer']
## UI configuration flags invalid before Maya 2009
kUIConfigFlags2009 = [
	'-nParticles',
	'-organizeByLayer',
	'-showAnimLayerWeight',
	'-autoExpandLayers',
	'-showAssets',
	'-showContainedOnly',
	'-showPublishedAsConnected',
	'-showContainerContents',
	'-containersIgnoreFilters',
	'-animLayerFilterOptions',
	'-constrainDrag',
	'-mergeConnections',
	'-showRelationships',
	'-opaqueContainers',
	'-heatMapDisplay',
	'-range']
## UI configuration flags invalid before Maya 2008
kUIConfigFlags2008 = [
	'-jointXray',
	'-activeComponentsXray',
	'-lineWidth',
	'-shadingModel']

def removeFlagArgPairFromUIConfigurationScript(line, flag):
	"""Remove a specified flag from a line in a uiConfigurationScriptNode string in a .ma file"""
	# make sure the incoming flag is correctly formatted
	if not flag.find('-') == 0: flag = '-%s'%flag
	if not flag.find(' ') == len(flag)-1: flag = '%s '%flag
	# early out if the formatted flag in fact does not exist
	if line.find(flag) < 0: return line
	# depending upon the location in the configuration string, line breaks may be expressed as an escape character or as an escape character in a string
	if line.find('\\n') > -1: return '%s%s'%(line[0:line.find(flag)].rstrip(), line[line.find(flag):len(line)][line[line.find(flag):len(line)].find('\\n')+len('\\n'):len(line)])
	else: return '%s%s'%(line[0:line.find(flag)].rstrip(), line[line.find(flag):len(line)][line[line.find(flag):len(line)].find('\n'):len(line)])

def patchMayaAsciiFile(file, toVersion):
	"""
	Patch a Maya Ascii file to attempt to make it backward compatible as far as
	8.5. This function will bake animation layers for old versions of Maya and
	remove other invalid requirements, flags, etc. Not all compatibility is
	presumed to be fixed; please use at your own risk.
	"""
	try: toVersion = float(toVersion)
	except: return False
	
	# if the file is from Maya 2009 or newer and is going to 2008 or 8.5, then bake animation layers
	if toVersion < 2009.0 and amTools.__mayaVersion__ > 2008.0:
		cmds.file(file, o=True, force=True)
		animLayers = cmds.ls(type='animLayer')
		affectedNodes = []
		for layer in animLayers:
			if cmds.listConnections(layer):
				for node in cmds.listConnections(layer):
					type = cmds.nodeType(node)
					if type and not type.find('animBlendNode') == 0 and not type == 'animLayer': affectedNodes.append(node)
		affectedNodes = set(affectedNodes)
		for node in affectedNodes:
			cmds.bakeResults(node, time=(cmds.findKeyframe(node, w='first'),cmds.findKeyframe(node, w='last')))
			amTools.utilities.animation.smoothAnimCurves(node, False)
		for layer in animLayers:
			try: cmds.delete(layer)
			except: pass
		cmds.file(s=True, force=True)
	
	try:
		readFile = open(file)
		lines = readFile.read().split('\n')
	except:
		sys.stderr.write('WARNING: Unable to read file: %s.\n'%file)
		return False
	
	newLines = []
	meshNodeAttribute = False # specifies whether the current line is setting an attribute on a mesh node
	animLayerNodeAttribute = False # specifies whether the current line is setting an attribute on an animLayer node
	for line in lines:
		if line.find('requires maya') == 0:
			if toVersion > 8.5: newLines.append('requires maya "%i";'%toVersion)
			else: newLines.append('requires maya "%s";'%toVersion)
			continue
		if toVersion < 2011.0:
			if (
				line.find('".bnr"') > -1 or # unsupported mesh attribute 
				line.find('".hfd"') > -1 or # unsupported mesh attribute
				line.find('".unw"') > -1 # unsupported time attribute
				): continue
			# remove unsupported flags from ui configuration script
			for flag in kUIConfigFlags2011:
				if line.find(flag) > -1: line = removeFlagArgPairFromUIConfigurationScript(line, flag)
			# TODO: find solution for camera sequencer editor panel
		if toVersion < 2010.0:
			if line.find('relationship ') == 0: continue # unsupported command
		if toVersion < 2009.0:
			if line.find('".pv"') > -1: # unsupported mesh attribute
				for prevline in reversed(newLines):
					if prevline.find('\t') == 0: continue
					else:
						if (prevline.find('createNode mesh') == 0): meshNodeAttribute = True
						else: meshNodeAttribute = False
						break
				if meshNodeAttribute:
					meshNodeAttribute = False
					continue
			elif line.find('requires "stereoCamera"') == 0: # non-existent plug-in
				continue
			elif line.find('createNode animLayer') == 0: # unsupported node
				animLayerNodeAttribute = True
				continue
			if animLayerNodeAttribute and line.find('\t') == 0: continue
			else: animLayerNodeAttribute = False
			# remove unsupported flags from ui configuration script
			for flag in kUIConfigFlags2009:
				if line.find(flag) > -1: line = removeFlagArgPairFromUIConfigurationScript(line, flag)
			# TODO: find solution for stereo UI object
		if toVersion < 2008.0:
			if line.find('".cvd"') > -1: continue
			if line.find('.bp"') > -1: continue
			for flag in kUIConfigFlags2008:
				if line.find(flag) > -1: line = removeFlagArgPairFromUIConfigurationScript(line, flag)
		newLines.append(line)
	
	readFile.close()
	newContents=''
	for line in newLines:
		newContents = '%s%s\n'%(newContents, line)
	
	try: writeFile = open(file, 'w')
	except:
		sys.stderr.write('WARNING: Unable to patch file: %s\n'%file)
		return False
	writeFile.write(newContents)
	writeFile.close()
	return True

def batchExport(sourcePath, destPath, toFileType='fbx', recursively=True, matchDirectorySructure=True, **keywords):
	"""
	Batch export files in one location to another location. Returns True on
	success. Only intended for use in standalone mode; otherwise FBX settings
	are not respected. Not all FBX Export settings are currently supported. Not
	all versions of Maya have been completely tested; please tell me if you
	find errors in old versions.
	@param filePatterns List corresponding to different file extensions to parse
	@param filterPrefix List corresponding to required prefixes in file names
	@param filterSuffix List corresponding to required suffixes in file names
	@param filterContains List corresponding to required string in file names
	@param addPrefix String to prefix on all exported files
	@param addSuffix String to suffix on all exported files
	@param bakeAll String specifying object types on which to bake animation
	@param bakeAllRange Tuple or list specifying a frame range
	@param maVersion Version of Maya to set for .ma exports
	@param fbxVersion FBXFileVersion string
	@param fbxAscii FBXExportInAscii
	@param fbxBake FBXExportBakeComplexAnimation boolean
	@param fbxBakeStart FBXExportBakeComplexStart float
	@param fbxBakeEnd FBXExportBakeComplexEnd
	@param fbxAnimOnly FBXExportAnimationOnly boolean
	@param fbxConstraints FBXExportConstraints boolean
	@param fbxUnit FBXConvertUnitString and FBXExportConvertUnitString
	@param fbxUpAxis FBXExportUpAxis
	@param fbxAxisConvert FBXExportAxisConversionMethod
	@param fbxScale FBXExportScaleFactor
	"""
	# make sure that the file type string comes in as expected
	try:
		toFileType = toFileType.lower()
		toFileType = toFileType[toFileType.rfind('.')+1:len(toFileType)]
	except: raise
	
	if toFileType == 'fbx':
		# early out if the plug-in has not been loaded
		try: cmds.FBXExport
		except:
			try: cmds.loadPlugin('fbxmaya')
			except:
				sys.stderr.write('ERROR: FBX Export Plug-in was not detected.\n')
				return False
		# configure FBX export settings
		try: mel.eval('FBXExportFileVersion %s'%keywords['fbxVersion']) # absent before Maya 2009, but should simply print a benign error message
		except: pass
		try: mel.eval('FBXExportAscii %s'%keywords['fbxAscii'].__str__().lower())
		except: pass
		try:
			mel.eval('FBXExportBakeComplexAnimation -v %s'%keywords['fbxBake'].__str__().lower())
			try: mel.eval('FBXExportBakeComplexStart -v %s'%keywords['fbxBakeStart'])
			except: mel.eval('FBXExportBakeComplexStart -v %i'%math.floor(cmds.playbackOptions(q=True, min=True)))
			try: mel.eval('FBXExportBakeComplexEnd -v %s'%keywords['fbxBakeEnd'])
			except: mel.eval('FBXExportBakeComplexEnd -v %i'%math.ceil(cmds.playbackOptions(q=True, max=True)))
		except: pass
		try: mel.eval('FBXExportAnimationOnly -v %s'%keywords['fbxAnimOnly'].__str__().lower())
		except: pass
		try: mel.eval('FBXExportConstraints -v %s'%keywords['fbxConstraints'].__str__().lower())
		except: pass
		try: mel.eval('FBXExportConvertUnitString -v %s'%keywords['fbxUnit'])
		except:
			try: mel.eval('FBXConvertUnitString -v %s'%keywords['fbxUnit'])
			except: pass
		try: mel.eval('FBXExportUpAxis -v %s'%keywords['fbxUpAxis'])
		except: pass
		try: mel.eval('FBXExportAxisConversionMethod -v %s'%keywords['fbxAxisConvert'])
		except: pass
		try: mel.eval('FBXExportScaleFactor -v %s'%keywords['fbxScale'])
		except: pass
	elif toFileType == 'ma':
		try:
			maVersion = keywords['maVersion']
			maVersion = convertValidTypesToStringList(maVersion, [types.StringTypes, types.IntType, types.FloatType])
			maVersion = maVersion[0]
		except: maVersion = None
	else:
		sys.stderr.write('ERROR: %s is not a supported file type.\n'%toFileType)
		return False
	
	# parse the keywords
	try: filePatterns = keywords['filePatterns']
	except: filePatterns = ['mb', 'ma']
	try: filterPrefix = keywords['filterPrefix']
	except: filterPrefix = ['']
	try: filterSuffix = keywords['filterSuffix']
	except: filterSuffix = ['']
	try: filterContains = keywords['filterContains']
	except: filterContains = ['']
	try: addPrefix = '%s'%keywords['addPrefix']
	except: addPrefix = ''
	try: addSuffix = '%s'%keywords['addSuffix']
	except: addSuffix = ''
	try:
		bakeAll = keywords['bakeAll']
		if not isinstance(bakeAll, types.StringTypes):
			sys.stderr.write("WARNING: Invalid argument %s specified for bakeAll. Type 'dag' is being used instead.\n"%bakeAll)
			bakeAll = 'dag'
	except: bakeAll = None
	try:
		bakeAllRange = keywords['bakeAllRange']
		if not type(bakeAllRange) == types.ListType or not type(bakeAllRange) == types.TupleType or not len(bakeAllRange) == 2:
			sys.stderr.write('WARNING: Invalid argument %s specified for bakeAllRange. Timeline is being used instead.\n'%bakeAllRange)
			bakeAllRange = None
	except: bakeAllRange = None
	
	# create the destination folders
	if matchDirectorySructure:
		if copyDirectoryStructure(sourcePath, destPath, False) == False: return False
	else:
		try: os.listdir(destPath)
		except: 
			try: os.makedirs(destPath)
			except: return False
	
	# get a list of all of the source files
	files = find(sourcePath, recursively, False, paths='relative', filePatterns=filePatterns, filterPrefix=filterPrefix, filterSuffix=filterSuffix, filterContains=filterContains)
	
	# export an fbx for each file
	for file in files:
		# build the export path and filename
		relativeLocation = ''
		filename = file[0:file.rfind('.')]
		if file.rfind('/') > -1:
			if matchDirectorySructure: relativeLocation = file[0:file.rfind('/')+1]
			filename = file[file.rfind('/')+1:file.rfind('.')]
		exportAsString = '%s/%s%s%s%s.%s'%(destPath, relativeLocation, addPrefix, filename, addSuffix, toFileType)
		try:
			# open the source file
			cmds.file('%s/%s'%(sourcePath, file), o=True, force=True)
			# export to the proper location
			try:
				if bakeAll:
					try:
						if not bakeAllRange: cmds.bakeResults(cmds.ls(type=bakeAll), sm=True, time=(math.floor(cmds.playbackOptions(q=True, min=True)),math.ceil(cmds.playbackOptions(q=True, max=True))))
						else: cmds.bakeResults(cmds.ls(type=bakeAll), sm=True, time=bakeAllRange)
					except: sys.stderr.write('WARNING: Unable to bake objects of type %s in file %s.\n'%(bakeAll, file))
					try:
						for object in cmds.ls(type=bakeAll):
							amTools.utilities.animation.smoothAnimCurves(object, False)
					except: sys.stderr.write('WARNING: Unable to correct tangents on baked objects of type %s in file %s.\n'%(bakeAll, file))
				if toFileType == 'fbx': mel.eval('FBXExport -f "%s";'%exportAsString) # TODO: failing on patched .ma files
				elif toFileType == 'ma':
					cmds.file(exportAsString, ea=True, type='mayaAscii', force=True)
					patchMayaAsciiFile(exportAsString, maVersion)
			except: sys.stderr.write('WARNING: Unable to export the file %s. It is being skipped.\n'%file[file.rfind('/')+1:len(file)])
		except: sys.stderr.write('WARNING: Unable to read the file %s. It is being skipped.\n'%file[file.rfind('/')+1:len(file)])
	
	return True