"""
Utility functions for working with animations.

\b Creation \b Info:

\b Donations: http://adammechtley.com/donations/

\b License: The MIT License

Copyright (c) 2011 Adam Mechtley (http://adammechtley.com)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the 'Software'), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED 'AS IS', WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

\namespace amTools.utilities.animation
"""

import sys, types
import maya.cmds as cmds

def matchInOutTangents(objects):
	"""Average the in- and out- tangents on an individual animation curve, all animation curves on an object, or on a series of objects."""
	if type(objects) is types.StringType: objects = [objects]
	if type(objects) is not types.ListType or type(objects) is not types.TupleType:
		sys.stderr.write("ERROR: Unable to match in-out tangents on object %s. Argument must be a string, list, or tuple of objects or attribute names.\n")
		return False
	# TODO: average tangents
	return True

def smoothAnimCurves(objects, isLoop):
	"""Set all keys on provided objects to auto tangent, optionally matching in and out tangents."""
	if isinstance(objects, types.StringTypes):
		objects = [objects]
	if not isinstance(objects, types.ListType) and not isinstance(objects, types.TupleType):
		sys.stderr.write("ERROR: Unable to smooth animation curves on object %s. Argument must be a string, list, or tuple of objects or attribute names.\n")
		return False
	for object in objects:
		cmds.selectKey(object)
		cmds.keyTangent(itt="spline", ott="spline")
		if isLoop: matchInOutTangents(object)
	return True