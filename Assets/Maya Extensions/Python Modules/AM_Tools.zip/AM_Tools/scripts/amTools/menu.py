"""
This module creates a menu in the Maya main menu to contain all of the tools in
the amTools package. Individual requirements for each module in the package are
listed in the modules themselves. This module is automatically imported when
you import the amTools package.

\b Creation \b Info:

\b Donations: http://adammechtley.com/donations/

\b License: The MIT License

Copyright (c) 2011 Adam Mechtley (http://adammechtley.com)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the 'Software'), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED 'AS IS', WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

\namespace amTools.menu
"""

import re
import maya.cmds as cmds
import maya.mel as mel
import amTools
import amTools.modeling as modeling
import amTools.rigging as rigging
import amTools.unity as unity
import amTools.utilities.debug as debug

## the name of the AM Tools menu
kAMToolsMenuName = "amToolsMenu"

def build():
	"""Creates the main menu for AM Tools"""
	# create the main menu
	mainWindow = mel.eval( "global string $gMainWindow;$temp = $gMainWindow")
	if cmds.menu(kAMToolsMenuName, q=True, exists=True):
		cmds.deleteUI(kAMToolsMenuName, menu=True)
	cmds.menu(kAMToolsMenuName, parent=mainWindow, tearOff=True, label="AM Tools")
	
	# add modeling tools
	cmds.menuItem(label=modeling.makeRibbons.kToolName, command=modeling.makeRibbons.menuItem)
	cmds.menuItem(divider=True)
	
	# add rigging tools
	cmds.menuItem(label=rigging.exposeTransform.kToolName, command=rigging.exposeTransform.menuItem)
	cmds.menuItem(label=rigging.insertParents.kToolName, command=rigging.insertParents.menuItem)
	cmds.menuItem(label=rigging.forearmSetup.kToolName, command=rigging.forearmSetup.menuItem)
	cmds.menuItem(label=rigging.hipConstraint.kToolName, command=rigging.hipConstraint.menuItem)
	cmds.menuItem(label=rigging.hipSetup.kToolName, command=rigging.hipSetup.menuItem)
	cmds.menuItem(label=rigging.shoulderConstraint.kToolName, command=rigging.shoulderConstraint.menuItem)
	cmds.menuItem(label=rigging.shoulderSetup.kToolName, command=rigging.shoulderSetup.menuItem)
	cmds.menuItem(divider=True)
	
	# add Unity tools
	cmds.menuItem(label='Unity', subMenu=True, tearOff=True)
	for item in unityExportItems:
		cmds.menuItem(label=item, cb=unityExportItemsStatus[unityExportItems[item]], command='amTools.menu.setUnityModifyExportItemStatus("%s")'%(item))
	cmds.menuItem(divider=True)
	cmds.menuItem(label='Prep for Manual FBX Export', command='amTools.unity.modifyExport()')
	try: cmds.setParent('..', menu=True) # in case module is imported running headless
	except: pass
	cmds.menuItem(divider=True)
	
	# add debugging tools
	cmds.menuItem(label="API Debug Mode", cb=mel.eval('$gAMToolsAPIDebugMode = $gAMToolsAPIDebugMode'), command=debug.menuItem)
	cmds.menuItem(divider=True)
	
	# add the support menu item
	cmds.menuItem(label="Support", command='cmds.launch(web="http://adammechtley.com/downloads/python/documentation/amtools/%s/")'%amTools.kVersionNumber)

def getUnityModifyExportItems():
	"""Populate the unityExportItems dict and the uniytExportItemsStatus dict."""
	scriptFile = open(unity.__file__.replace('.pyc', '.py'), 'r')
	inMethodBody = False
	for line in scriptFile:
		if re.search('def modifyExport', line):
			inMethodBody = True
			continue
		if not inMethodBody or '"""' in line: continue
		desc = line[line.rfind('# ')+2:].rstrip()
		if desc == 'return' or desc == 'pass': continue
		func = re.search('[\w.]+', line).group(0)
		unityExportItems[desc] = func
		if line.find('#') < line.find(func): unityExportItemsStatus[func] = False
		else: unityExportItemsStatus[func] = True
	scriptFile.close()

def setUnityModifyExportItemStatus(description):
	"""Enable or disable the indicated function"""
	functionName = unityExportItems[description]
	unityExportItemsStatus[functionName] = not unityExportItemsStatus[functionName]
	scriptFile = open(unity.__file__.replace('.pyc', '.py'), 'r')
	newLines = ''
	inMethodBody = False
	for line in scriptFile:
		if re.search('def modifyExport', line):
			inMethodBody = True
			newLines += line
			continue
		if not inMethodBody or '"""' in line:
			newLines += line
			continue
		if unityExportItemsStatus[functionName]:
			line = re.sub(re.escape('#%s'%functionName), functionName, line, 1)
		else:
			line = re.sub(re.escape('%s'%functionName), '#%s'%functionName, line, 1)
		newLines += line
	scriptFile.close()
	scriptFile = open(unity.__file__.replace('.pyc', '.py'), 'w')
	scriptFile.write(newLines)
	scriptFile.close()
	reload(unity)

## dictionary with description : functionName pairs
unityExportItems = {}
## dictionary with functionName : enabledStatus pairs
unityExportItemsStatus = {}

# store the current status of unity export items
getUnityModifyExportItems()

# build the menu
build()